"""
Configuration parameters for the Energy Management System Scoring Tool.
All magic numbers and constants are defined here for maintainability.
"""

# ---------------- Energy Cost Weights ----------------
# Weight applied to the total energy cost in the score formula
W5_ENERGY_COST = 1.0    # adjust as needed

# Unit costs ($ per kWh equivalent)
GRID_UNIT_COST   = 5.0
DIESEL_UNIT_COST = 15.0
SOLAR_UNIT_COST  = 0.0


# Data processing constants
POWER_CONVERSION_FACTOR = 1000  # Convert from kW to W
REFERENCE_DATA_ROWS = 1680  # Number of rows with load/solar data in reference file

# Time constants
DAYS_PER_WEEK = 7
HOURS_PER_DAY = 24
QUARTERS_PER_HOUR = 4
MINUTES_PER_QUARTER = 15  # Each timestep is 15 minutes

# Default evaluation parameters
DEFAULT_EVALUATION_DAYS = 7
DEFAULT_NUM_SITES = 10

# Scoring weights
DIESEL_START_PENALTY = 300.0  # Penalty points per diesel generator start
DIESEL_RUNTIME_PENALTY = 1.0  # Penalty points per minute of diesel runtime
MAX_DIESEL_RUN_PENALTY = 0.95  # Penalty points per minute of longest diesel run
GRID_USAGE_PENALTY = 0.25  # Penalty points per minute of grid usage

# Battery constraints
MAX_SOC = 1.0  # Maximum state of charge (100%)

# Logging configuration
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(funcName)s:%(lineno)d - %(message)s'
LOG_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
DEFAULT_LOG_LEVEL = 'INFO'
DEFAULT_LOG_FILE = 'energy_management.log'  # Set to None to disable file logging
LOG_TO_CONSOLE = True  # Set to False to disable console output
